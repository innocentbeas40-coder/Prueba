<?php
require_once "Planta.php";

class Arbol extends Planta
{
    private string $Variedad;
    private string $TipoTronco;
    private float $RadioTronco;
    private string $Color;
    private string $TipoHojas;

    public function __construct(
        string $Nombre, float $AlturaTallo, bool $TieneHojas, string $ClimaIdeal,
        string $Variedad, string $TipoTronco, float $RadioTronco, string $Color, string $TipoHojas
    ) {
        // ERROR 2: falta llamar al constructor de Planta
        $this->Variedad = $Variedad;
        $this->TipoTronco = $TipoTronco;
        $this->RadioTronco = $RadioTronco;
        $this->Color = $Color;
        $this->TipoHojas = $TipoHojas;
    }

    public function Saludar(): void
    {
        echo "Hola, soy un árbol<br>";
    }

    public function MostrarInformacion(): void
    {
        parent::MostrarInformacion();
        echo "Variedad: " . $this->Variedad . "<br>";
        echo "Tipo de tronco: " . $this->TipoTronco . "<br>";
        echo "Radio del tronco: " . $this->RadioTronco . " m<br>";
        echo "Color: " . $this->Color . "<br>";
        echo "Tipo de hojas: " . $this->TipoHojas . "<br>";
        echo "Nombre del árbol: " . $this->Nombre . "<br>"; // ERROR 3: private heredado
    }
}
