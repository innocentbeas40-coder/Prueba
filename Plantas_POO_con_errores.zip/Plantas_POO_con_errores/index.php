<?php
require_once "Arbol.php";
require_once "Flor.php";
require_once "Arbusto.php";

$Arbol = new Arbol("Roble", 8.5, true, "Templado", "Roble común", "Leñoso", 0.45, "Marrón", "Caducas");
$Flor = new Flor("Rosa", 0.6, true, "Templado", "Rojo", 32, "Amarillo", "Rosa híbrida", "Primavera");
$Arbusto = new Arbusto("Hortensia", 1.2, true, "Húmedo", 1.5, true, "Macrophylla", "Verde", true);

echo "<h1>Práctica de depuración: Plantas</h1>";

echo "<h2>Árbol</h2>";
$Arbol->Saludar();
$Arbol->MostrarInformacion();

echo "<hr><h2>Flor</h2>";
$Flor->Saludar();
$Flor->MostrarInformacion();

echo "<hr><h2>Arbusto</h2>";
$Arbusto->Saludar(); // Debe funcionar según el enunciado
$Arbusto->MostrarInformacion();
